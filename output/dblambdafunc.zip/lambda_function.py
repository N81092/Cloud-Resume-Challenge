


import boto3
from boto3.dynamodb.conditions import Key

dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('visitCount')

def lambda_handler(event, context):
    # Current visit count
    response = table.get_item(Key={'site_id':'0'})
    visit_count = response['Item']['visit']
    
    # Increment
    visit_count += 1
    
    # Update 
    table.update_item(
        Key={'site_id': '0'},
        UpdateExpression='SET visit = :val',
        ExpressionAttributeValues={':val': visit_count}
    )
  
     response = {
        "headers": {
            "content-type" : "application/json"
        },
        "status_code": 200,
        "body" : {
            "count": visit_count
        }
    }
    
    #response
    return response

